from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

# Create chatbot instance
chatbot = ChatBot(
    "SmartBot",
    storage_adapter="chatterbot.storage.SQLStorageAdapter",
    database_uri="sqlite:///database.sqlite3",
    logic_adapters=[
        {
            'import_path': 'chatterbot.logic.BestMatch',
            'default_response': "I'm sorry, I don't understand that. Can you ask something else?",
            'maximum_similarity_threshold': 0.85  # Ensures relevant responses
        }
    ]
)

# Train chatbot with custom questions & answers
trainer = ListTrainer(chatbot)
trainer.train([
    "Hello",
    "Hi there! How can I assist you today?",
    "Hi",
    "Hello! What can I do for you?",
    "Who created you?",
    "I was created using Python and ChatterBot.",
    "What is Python?",
    "Python is a high-level programming language used for AI, web development, and more.",
    "What is AI?",
    "Artificial Intelligence (AI) is a branch of computer science focused on building smart machines.",
    "Tell me a joke",
    "Why did the programmer go broke? Because he used up all his cache!",
    "What is Machine Learning?",
    "Machine Learning is a subset of AI that allows computers to learn from data.",
    "What is Java?",
    "Java is a widely-used programming language for web and mobile applications.",
    "What is C++?",
    "C++ is a programming language commonly used for game development and high-performance applications.",
    "Bye",
    "Goodbye! Have a great day!"
    

    
    "What is HTML?", "HTML is the backbone of web pages, defining structure and content.",
    "What is CSS?", "CSS makes the web beautiful by styling HTML elements.",
    "What is JavaScript?", "JavaScript brings websites to life with interactivity and dynamic content.",
    "What is SQL?", "SQL is the language of databases, helping to store and manage structured data.",
    "What is Git?", "Git is a version control system that helps developers collaborate efficiently.",
    "What is Cloud Computing?", "Cloud computing allows users to access data and apps over the internet instead of local storage.",
    "Who is the father of Computer Science?", "Alan Turing, the genius behind modern computing and AI!",
    "What is the Internet?","The Internet is like a giant library, but with memes and cat videos too!",
    "What is Cybersecurity?", "Cybersecurity protects your digital world from hackers and threats.",
    "What is an Operating System?", "An OS is the bridge between you and your computer hardware.",
    

    "Tell me something smart", "Did you know? The first computer bug was an actual moth stuck in a Harvard Mark II computer in 1947!",
    "Tell me something interesting", "The word 'robot' comes from a Czech word meaning 'forced labor'.",
    "What’s the best programming language?", "It depends! Python for AI, JavaScript for web, C++ for performance, and Rust for security.",
    "What is OpenAI?", "OpenAI is an AI research lab that created models like ChatGPT and DALL·E.",
    "What is the Turing Test?","The Turing Test determines if a machine can exhibit intelligent behavior indistinguishable from a human.",
    "How do computers think?", "Computers follow logic and algorithms, but true thinking is still a human trait!",
    "What is a Neural Network?","A Neural Network is an AI model inspired by the human brain, used for deep learning.",
    "What is Quantum Computing?","Quantum computers use quantum bits (qubits) to perform calculations at unimaginable speeds!",
    "What is Blockchain?", "Blockchain is a decentralized, secure ledger technology used in cryptocurrencies and secure transactions.",
    "Why do programmers love coffee?", "Because without coffee, there are too many runtime errors!"   
])

# Function to get chatbot response
def get_response(user_input):
    return chatbot.get_response(user_input)
