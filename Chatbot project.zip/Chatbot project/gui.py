import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import pyttsx3
from gtts import gTTS
import os
import ttkbootstrap as ttk
from chatbot import get_response

# Use gTTS for more natural voice (Set to True to enable)
USE_GTTS = False

# Initialize pyttsx3
engine = pyttsx3.init()

# Select a high-quality voice
voices = engine.getProperty('voices')
for voice in voices:
    if "david" in voice.name.lower() or "zira" in voice.name.lower():
        engine.setProperty('voice', voice.id)
        break

# Adjust voice settings for better clarity
engine.setProperty('rate', 160)  # Adjust speed for better pronunciation
engine.setProperty('volume', 1.0)  # Max volume

# Function to make chatbot speak
def speak(text):
    def run():
        if USE_GTTS:
            tts = gTTS(text=text, lang="en", slow=False, tld="co.uk")  # Use British accent for clarity
            tts.save("response.mp3")
            os.system("start response.mp3")
        else:
            engine.say(text)
            engine.runAndWait()

    threading.Thread(target=run, daemon=True).start()

# Function to get chatbot response and display it
def send_message():
    user_input = user_entry.get().strip()
    if not user_input:
        return

    chat_window.config(state=tk.NORMAL)
    chat_window.insert(tk.END, f"You: {user_input}\n", "user")

    response = get_response(user_input)
    chat_window.insert(tk.END, f"Bot: {response}\n\n", "bot")

    speak(response)
    chat_window.config(state=tk.DISABLED)
    chat_window.yview(tk.END)
    user_entry.delete(0, tk.END)

# Function to clear chat
def clear_chat():
    chat_window.config(state=tk.NORMAL)
    chat_window.delete(1.0, tk.END)
    chat_window.config(state=tk.DISABLED)

# Function to save chat history
def save_chat():
    file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
    if file_path:
        with open(file_path, "w") as file:
            chat_text = chat_window.get(1.0, tk.END)
            file.write(chat_text)
        messagebox.showinfo("Success", "Chat saved successfully!")

# GUI Setup
root = ttk.Window(themename="darkly")  # Using ttkbootstrap theme
root.title("Smart AI Chatbot")
root.geometry("550x650")

# Styling
bg_color = "#1E1E1E"
bot_color = "#32CD32"
user_color = "#00BFFF"

root.configure(bg=bg_color)

# Chat window
chat_frame = ttk.Frame(root)
chat_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

chat_window = tk.Text(chat_frame, bg="#252526", fg="white", font=("Arial", 12), width=50, height=20, wrap=tk.WORD)
chat_window.tag_configure("user", foreground=user_color, font=("Arial", 12, "bold"))
chat_window.tag_configure("bot", foreground=bot_color, font=("Arial", 12, "italic"))
chat_window.config(state=tk.DISABLED)
chat_window.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Scrollbar
scrollbar = ttk.Scrollbar(chat_frame, command=chat_window.yview)
chat_window.config(yscrollcommand=scrollbar.set)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# User input
user_entry = ttk.Entry(root, width=50, font=("Arial", 14), bootstyle="primary")
user_entry.pack(pady=10, padx=10, fill=tk.X)

# Button frame
button_frame = ttk.Frame(root)
button_frame.pack(pady=10)

send_button = ttk.Button(button_frame, text="Send", command=send_message, bootstyle="success-outline", width=15)
send_button.grid(row=0, column=0, padx=5)

clear_button = ttk.Button(button_frame, text="Clear Chat", command=clear_chat, bootstyle="danger-outline", width=15)
clear_button.grid(row=0, column=1, padx=5)

save_button = ttk.Button(button_frame, text="Save Chat", command=save_chat, bootstyle="warning-outline", width=15)
save_button.grid(row=0, column=2, padx=5)

root.mainloop()
